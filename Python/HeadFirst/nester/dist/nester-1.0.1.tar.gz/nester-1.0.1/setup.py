from distutils.core import setup

setup(
		name			= 'nester',
		version			= '1.0.1',
		py_modules		= ['ch01'],
		author			= 'hfpython',
		author_email	= 'hfpython@headfirstlabs.com',
		url				= 'http://www.headfirstlabs.com',
		description		= 'A simple printer of nested lists.',
		)

